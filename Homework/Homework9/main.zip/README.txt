HOMEWORK 9: DISTANCE FIELDS & FAST MARCHING METHOD


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



NAIVE ALGORITHM:

Order Notation:

Timing Experiment Data:

Discussion:



IMPROVED ALGORITHM:

Order Notation:

Timing Experiment Data:

Discussion:



FAST MARCHING METHOD (with a map):

Order Notation:

Timing Experiment Data:

Discussion:



DISTANCE FIELD VISUALIZATIONS FOR EXTRA CREDIT:




FAST MARCHING METHOD (with a hash table) FOR EXTRA CREDIT:

Order Notation:

Timing Experiment Data:

Discussion:



MISC. COMMENTS TO GRADER:  
Optional, please be concise!






