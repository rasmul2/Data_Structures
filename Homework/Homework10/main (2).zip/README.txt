HOMEWORK 10: MULTIPLE INHERITANCE & EXCEPTIONS


NAME:  < Loki Rasmussen >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< Bobby Parker, the internet >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 50 >



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

Please, my code runs on my computer and I did everything and took a late day to try to get it to work and it just doesn't on the server, but it's almost entirely right, I just don't know how to fix the child terminated error on the server




