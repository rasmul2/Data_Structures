#include <cassert>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <algorithm>
using namespace std;

#include "polygons.h"
#include "utilities.h"

//==============================================================
//POLYGON


Polygon::Polygon(){}

Polygon::Polygon(const string &name, const vector <Point>& pts){
	for (vector<Point>::const_iterator i = pts.begin(); i != pts.end(); ++i){
		verts.push_back(*i);
	}
	shape_name = name;
}

bool Polygon::HasARightAngle(const Point&a, const Point&b, const Point&c){
	double angle = Angle(a, b, c);
	if(RightAngle(angle)) return true;
	else{return false;}
}

bool Polygon::HasEqualSides(const Point&a,const Point&b, const Point&c, const Point&d){
	double side1 = DistanceBetween(a,b);
	double side2 = DistanceBetween(c,d);
	if(side1 == side2) return true;
	else{return false;}
}

bool Polygon::HasParallelSides(const Point&a,const Point&b, const Point&c, const Point&d){
	Vector side1 = Vector(a,b);
	Vector side2 = Vector(c,d);
	if(Parallel(side1, side2)) return true;
	else{return false;}
}

bool Polygon::IsSymetrical(const Point&a, const Point&b, const Point&c, const Point&d){
	
}

bool Polygon::HasAllEqualSides(){
double side1 = DistanceBetween(verts[0], verts[1]);
	for (int i = 0, j = 1; i < verts.size(); ++i)
	{
		double side2 = DistanceBetween(verts[i], verts[j]);
		if (!EqualSides(side1, side2))
		{
		 	return false;
		}
		else{
			if (j==verts.size()-1)
			{
				j=0;
			}
			else{
				j++;
			}
		}
	}
	return true;
}
bool Polygon::HasAllEqualAngles(){
	double angle1 = Angle(verts[0], verts[1], verts[2]);
	
	cout << shape_name << endl;
	for(int i = 1, j = 2, k = 3; k< verts.size();){
		double angle2 = Angle(verts[i], verts[j], verts[k]);
		cout << verts[i].x << verts[i].y << endl;
		cout << verts[j].x << verts[j].y << endl;
		cout << verts[k].x << verts[k].y << endl;
		if(!EqualAngles(angle1, angle2)){
			return false;
		}

		else{
			if (k==verts.size()-1)
			{
				k=0;
			}
			else{
				k++;
			}
			if (j==verts.size()-1)
			{
				j=0;
			}
			else{
				j++;
			}
		}
		return true;
	}

}

bool Polygon::HasARightAngle(){
	for (int i = 0, j = 1, k= 2; i < verts.size(); ++i)
	{
		double angle = Angle(verts[i], verts[j], verts[k]);
		if (RightAngle(angle))
		{
		 	return true;
		}
		else{
			if (k==verts.size()-1)
			{
				k=0;
			}
			else{
				k++;
			}
			if (j==verts.size()-1)
			{
				j=0;
			}
			else{
				j++;
			}
		}
	}
	return false;


}

bool Polygon::HasAnObtuseAngle(){
for (int i = 0, j = 1, k= 2; i < verts.size(); ++i)
	{
		double angle = Angle(verts[i], verts[j], verts[k]);
		if (ObtuseAngle(angle))
		{
		 	return true;
		}
		else{
			if (k==verts.size()-1)
			{
				k=0;
			}
			else{
				k++;
			}
			if (j==verts.size()-1)
			{
				j=0;
			}
			else{
				j++;
			}
		}
	}
	return false;
}

bool Polygon::HasAnAcuteAngle(){
	for (int i = 0, j = 1, k= 2; i < verts.size(); ++i)
	{
		double angle = Angle(verts[i], verts[j], verts[k]);
		if (AcuteAngle(angle))
		{
		 	return true;
		}
		else{
			if (k==verts.size()-1)
			{
				k=0;
			}
			else{
				k++;
			}
			if (j==verts.size()-1)
			{
				j=0;
			}
			else{
				j++;
			}
		}
	}
	return false;

}

bool Polygon::IsConvex(){

}

bool Polygon::IsConcave(){

}

//=====================================================================
//QUADRILATERALS
Quadrilateral::Quadrilateral(): Polygon(){}

Quadrilateral::Quadrilateral(const string& name, const vector <Point>& verts):
Polygon(name, verts){
	if (verts.size() != 4) throw 69;
}

Trapezoid::Trapezoid(): Quadrilateral(){}

Trapezoid::Trapezoid(const string& name, const vector <Point>& verts): 
Quadrilateral(name, verts) {
	if (!HasParallelSides(verts[0], verts[1], verts[2], verts[3]) &&
	 !HasParallelSides(verts[1], verts[2], verts[3], verts[0])){
		throw 69;
	}
	
}

IsoscelesTrapezoid::IsoscelesTrapezoid(const string& name, const vector <Point>& verts){
	if(!IsSymetrical(verts[0], verts[1], verts[2], verts[3]) &&
		!IsSymetrical(verts[1], verts[2], verts[3], verts[0])){
		throw 69;
	}
}

Kite::Kite(const string& name, const vector <Point>& verts): 
Quadrilateral(name, verts){
	if(!HasEqualSides(verts[0], verts[1], verts[2], verts[3]) &&
		!HasEqualSides(verts[1], verts[2], verts[3], verts[0])){
		throw 69;
	}
}

Parallelogram::Parallelogram(const string& name,const vector <Point>& verts):
Trapezoid(name, verts), Kite(name, verts), Quadrilateral(name, verts){
	if(!HasParallelSides(verts[0], verts[1], verts[2], verts[3]) ||
	 !HasParallelSides(verts[1], verts[2], verts[3], verts[0])){
	 	throw 69;
	 }

	
}

Rectangle::Rectangle(const string& name, const vector <Point>& verts):
Kite(name, verts){
	if (!HasAllEqualAngles())
	{
		throw 69;
	}

}

Rhombus::Rhombus(const string& name, const vector <Point>& verts):
Kite(name, verts){
	if(!HasAllEqualAngles()){
		throw 69;
	}

}

Square::Square(const string& name, const vector <Point>& verts):
Rectangle(name, verts), Rhombus(name, verts){
	if(!HasAllEqualSides()){
		throw 69;
	}

}


//===================================================================
//TRIANGLES

Triangle::Triangle(): Polygon(){}

Triangle::Triangle(const string& name, const vector <Point>& verts): 
Polygon(name, verts) {
	if (verts.size() != 3) throw 69; 
}

IsoscelesTriangle::IsoscelesTriangle(const string& name, const vector <Point>& verts):
Triangle(name, verts){
	double side1 = DistanceBetween(verts[0], verts[1]);
	double side2 = DistanceBetween(verts[1], verts[2]);
	double side3 = DistanceBetween(verts[2], verts[0]);
	if(!EqualSides(side1, side2) && !EqualSides(side2, side3)&& 
		!EqualSides(side3, side1)){
			throw 69;
		}
}

EquilateralTriangle::EquilateralTriangle(const string& name,const vector <Point>& verts):
IsoscelesTriangle(name, verts), Triangle(name, verts){
	if(!HasAllEqualSides()){
			throw 69;
	}

}

RightTriangle::RightTriangle(const string& name, const vector <Point>& verts):
Triangle(name, verts){
	if(!HasARightAngle(verts[0], verts[1], verts[2])&&
		!HasARightAngle(verts[1], verts[2], verts[0])&&
		!HasARightAngle(verts[2], verts[0], verts[1])){
			throw 69;
		}

}

IsoscelesRightTriangle::IsoscelesRightTriangle(const string& name, const vector <Point>& verts):
IsoscelesTriangle(name, verts), RightTriangle(name, verts), Triangle(name, verts){

}

ObtuseTriangle::ObtuseTriangle(const string& name, const vector <Point>& verts):
Triangle(name, verts){
	if(!HasAnObtuseAngle()){
		throw 69;
	}

}

IsoscelesObtuseTriangle::IsoscelesObtuseTriangle(const string& name, const vector <Point>& verts):
ObtuseTriangle(name, verts), IsoscelesTriangle(name, verts), Triangle(name, verts){

}


//=======================================================================
//OTHER

Arrow::Arrow(const string& name, const vector <Point>& verts):
Polygon(name, verts){

}