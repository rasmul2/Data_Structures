HOMEWORK 6: CARCASSONNE RECURSION


NAME:  < Loki Rasmussen >



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< C++ online >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 100 for the two weeks >



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)
The dimensions of the board (h and w)?  h^w order notation 
The number of tiles (t)? first order notation
The number of road (r) and city (c) edges? the tile^4 to check each side
The number of duplicate tiles? don't understand, didnt have duplicates
Whether rotations are allowed?  rotation raises tile^4 by rotation direction 
Etc. 



SUMMARY OF PERFORMANCE OF YOUR PROGRAM ON THE PROVIDED PUZZLES:
# of solutions & approximate wall clock running time for different
puzzles with various command line arguments.
Obviously, I can't seem to get my program to run correclty and when it does it's rather slow



MISC. COMMENTS TO GRADER:  
(optional, please be concise!)


