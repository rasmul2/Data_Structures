#include <iostream>

void PrintPieces(Board &board, const std::vector<Tile*> &tiles, std::vector<Location> &locations,
	bool & all_solutions, bool & allow_rotations);